export default class ClientDto {
  CodCliente: number;
  Saldo: number;
}
