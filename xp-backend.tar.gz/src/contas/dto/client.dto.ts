export default class ClientDTO {
  CodCliente: number;
  Saldo: number | string;
}
