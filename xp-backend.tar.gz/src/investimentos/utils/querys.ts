const queryUpsert = (
  carteiraId: number,
  codAtivo: number,
  quantidade: number,
) => ({
  where: { carteiraId_codAtivo: { carteiraId, codAtivo } },
  update: {
    carteiraId,
    codAtivo,
    quantidade,
  },
  create: {
    carteiraId,
    codAtivo,
    quantidade,
  },
});

export default queryUpsert;
