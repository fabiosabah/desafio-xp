import queryUpsert from './querys';
export default queryUpsert;
