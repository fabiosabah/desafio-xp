export class CarteiraAtivoDto {
  id: number;
  carteiraId: number;
  codAtivo: number;
  quantidade: number;
}
