import {
  BadRequestException,
  Injectable,
  UnprocessableEntityException,
} from '@nestjs/common';
import { AtivosService } from 'src/ativos/ativos.service';
import { ContasService } from 'src/contas/contas.service';
import { PrismaService } from 'src/prisma/prisma.service';
import { InvestimentosDto } from './dto/investimentos.dto';
import queryUpsert from './utils';

@Injectable()
export class InvestimentosService {
  constructor(
    private prisma: PrismaService,
    private ativos: AtivosService,
    private contas: ContasService,
  ) {}

  async buy(investimentosDto: InvestimentosDto): Promise<void | Error> {
    const { codCliente, codAtivo, qtdeAtivo } = investimentosDto;
    const { id: carteiraId, saldo } = await this.contas.findWallet(codCliente);
    const ativo = await this.ativos.findOne(codAtivo);

    if (qtdeAtivo > ativo.QtdeAtivo)
      throw new BadRequestException(
        'The amount of asset to be sold cannot be greater than the amount available in the portfolio.',
      );

    const purchaseAmount = ativo.Valor * qtdeAtivo;

    if (purchaseAmount > saldo) {
      throw new BadRequestException(
        'Insufficient balance to make the purchase',
      );
    }

    const { quantidade } = await this.prisma.carteiraAtivo.findFirst({
      where: { carteiraId, codAtivo: ativo.CodAtivo },
    });
    const queryUpdate = {
      where: { codAtivo },
      data: { qtdDisponivel: ativo.QtdeAtivo - qtdeAtivo },
    };
    const qtdUpsert = qtdeAtivo + quantidade;
    const query = queryUpsert(carteiraId, codAtivo, qtdUpsert);

    try {
      await this.prisma.$transaction([
        this.prisma.ativo.update(queryUpdate),
        this.prisma.carteira.update({
          where: { id: carteiraId },
          data: {
            saldo: saldo - purchaseAmount,
          },
        }),
        this.prisma.carteiraAtivo.upsert(query),
      ]);
    } catch (err) {
      throw new UnprocessableEntityException('transaction operation failed');
    }
  }

  async sell(investimentosDto: InvestimentosDto): Promise<void | Error> {}
}
