var val = 10;
val = val.toFixed(2);
val = +val;
console.log(val);